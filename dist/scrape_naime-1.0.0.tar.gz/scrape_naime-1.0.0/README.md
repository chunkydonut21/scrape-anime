# ScrapeAnime

ScrapeAnime scrapes all Anime details and episodes from KissAnime.


## INSTALLATION
``` pip install scrape-anime ```